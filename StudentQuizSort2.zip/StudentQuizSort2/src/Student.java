
public class Student {

}
